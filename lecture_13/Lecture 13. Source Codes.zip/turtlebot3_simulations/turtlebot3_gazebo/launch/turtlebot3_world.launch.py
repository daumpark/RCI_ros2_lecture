#!/usr/bin/env python3
#
# Copyright 2019 ROBOTIS CO., LTD.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Authors: Joep Tool

# os 모듈을 임포트합니다. 파일 및 디렉토리 경로 작업을 위해 필요합니다.
import os

# ament_index_python.packages에서 get_package_share_directory 함수를 임포트합니다.
# 이 함수는 ROS 2 패키지의 공유 디렉토리 경로를 찾는 데 사용됩니다.
from ament_index_python.packages import get_package_share_directory
# launch 관련 클래스들을 임포트합니다.
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration


def generate_launch_description():
    # turtlebot3_gazebo 패키지의 launch 디렉토리 경로를 설정합니다.
    launch_file_dir = os.path.join(get_package_share_directory('turtlebot3_gazebo'), 'launch')
    # gazebo_ros 패키지의 공유 디렉토리 경로를 가져옵니다.
    pkg_gazebo_ros = get_package_share_directory('gazebo_ros')

    # 시뮬레이션 시간 사용 여부를 설정합니다. 기본값은 'true'입니다.
    use_sim_time = LaunchConfiguration('use_sim_time', default='true')
    # 터틀봇의 초기 x 좌표를 설정합니다. 기본값은 '-2.0'입니다.
    x_pose = LaunchConfiguration('x_pose', default='-2.0')
    # 터틀봇의 초기 y 좌표를 설정합니다. 기본값은 '-0.5'입니다.
    y_pose = LaunchConfiguration('y_pose', default='-0.5')

    # Gazebo 월드 파일의 경로를 설정합니다.
    world = os.path.join(
        get_package_share_directory('turtlebot3_gazebo'),
        'worlds',
        'turtlebot3_world.world'
    )

    # Gazebo 서버(gzserver)를 실행하는 launch 파일을 포함시킵니다.
    # world 인자로 위에서 설정한 월드 파일 경로를 전달합니다.
    gzserver_cmd = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_gazebo_ros, 'launch', 'gzserver.launch.py')
        ),
        launch_arguments={'world': world}.items()
    )

    # Gazebo 클라이언트(gzclient)를 실행하는 launch 파일을 포함시킵니다.
    gzclient_cmd = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_gazebo_ros, 'launch', 'gzclient.launch.py')
        )
    )

    # 로봇의 상태를 퍼블리시하는 robot_state_publisher를 실행하는 launch 파일을 포함시킵니다.
    # use_sim_time 인자를 전달하여 시뮬레이션 시간을 사용하도록 설정합니다.
    robot_state_publisher_cmd = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(launch_file_dir, 'robot_state_publisher.launch.py')
        ),
        launch_arguments={'use_sim_time': use_sim_time}.items()
    )

    # 터틀봇3 모델을 Gazebo에 스폰(생성)하는 launch 파일을 포함시킵니다.
    # x_pose와 y_pose 인자를 전달하여 터틀봇의 초기 위치를 설정합니다.
    spawn_turtlebot_cmd = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(launch_file_dir, 'spawn_turtlebot3.launch.py')
        ),
        launch_arguments={
            'x_pose': x_pose,
            'y_pose': y_pose
        }.items()
    )

    # LaunchDescription 객체를 생성합니다.
    ld = LaunchDescription()

    # 위에서 정의한 명령어들을 launch description에 추가합니다.
    ld.add_action(gzserver_cmd)
    ld.add_action(gzclient_cmd)
    ld.add_action(robot_state_publisher_cmd)
    ld.add_action(spawn_turtlebot_cmd)

    # 설정된 launch description을 반환합니다.
    return ld